/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Apps;

import static Apps.EncryptDecrypt.decrypt;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import Config.KoneksiDatabase;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import static javafx.css.StyleOrigin.USER;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Acer
 */
public class Obat extends javax.swing.JFrame {

    /**
     * Creates new form Obat
     */

    public Obat() {
        initComponents();
        setFullScreen();
         loadData();
    }
        public void loadData() {
        // Query untuk mengambil data dari database
       String query = "SELECT obat.*, user.nama as namaorang FROM obat LEFT JOIN user ON obat.nip = user.nip";


        // Kolom yang akan ditampilkan di JTable
        String[] columnNames = {"ID Obat", "Nama Obat", "Kategori","Jenis Obat", "Stok", "Harga", "Brand", "BPJS Status", "NIP", "Input Date", "Edit Date"};

        // Array untuk menampung data yang diambil dari database
        Object[][] data = new Object[0][columnNames.length];
        
        // Dapatkan koneksi dari KoneksiDatabase
        Connection conn = KoneksiDatabase.getConnection();
        
        if (conn != null) {
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
                // Hitung jumlah baris
                int rowCount = 0;
                while (rs.next()) {
                    rowCount++;
                }
                
                // Mengisi data array dengan data dari ResultSet
                data = new Object[rowCount][columnNames.length];
                int rowIndex = 0;
                rs.beforeFirst();  // Set ResultSet ke awal
                while (rs.next()) {
                    data[rowIndex][0] = rs.getInt("id_obat");
                    data[rowIndex][1] = rs.getString("nama_obat");
                    data[rowIndex][2] = rs.getString("kategori");
                    data[rowIndex][3] = rs.getString("jenis");
                    data[rowIndex][4] = rs.getInt("stok");
                    data[rowIndex][5] = rs.getString("harga");
                    data[rowIndex][6] = rs.getString("brand");
                    data[rowIndex][7] = rs.getString("bpjs_status");
                    data[rowIndex][8] = rs.getString("nip");
                    data[rowIndex][9] = rs.getTimestamp("input_date");
                    data[rowIndex][10] = rs.getTimestamp("edit_date");
                    rowIndex++;
                }

                // Buat DefaultTableModel dengan data yang telah diambil
                DefaultTableModel model = new DefaultTableModel(data, columnNames);

                // Set model ke tabel_obat
                tabel_obat.setModel(model);
                
            } catch (SQLException e) {
                System.out.println("Error mengambil data: " + e.getMessage());
                JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat memuat data.");
            } finally {
                // Pastikan koneksi ditutup setelah selesai
                KoneksiDatabase.tutupKoneksi(conn);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Koneksi ke database gagal.");
        }
    }
private void InputDataObat() {
       // Ambil data dari form
        String namaObat = nama_obat.getText(); // ambil dari JTextField
        String kategori = obat_kategori.getSelectedItem().toString(); // ambil dari JComboBox
        String jenis = jenisobat.getSelectedItem().toString();
        int stok = Integer.parseInt(stok_obat.getText()); // ambil dari JTextField
        String harga = harga_obat.getText(); // ambil dari JTextField
        String brand = brand_obat.getText(); // ambil dari JTextField
        String bpjsStatus = BPJS_status.getSelectedItem().toString(); // ambil dari JComboBox
        String nip = decrypt(SessionManager.getNip());

        // Buat query SQL untuk memasukkan data
        String query = "INSERT INTO obat (nama_obat, kategori, jenis, stok, harga, brand, bpjs_status, nip) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        // Dapatkan koneksi dari KoneksiDatabase
        Connection conn = KoneksiDatabase.getConnection();
        
        if (conn != null) {
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, namaObat);
                stmt.setString(2, kategori);
                stmt.setString(3, jenis);
                stmt.setInt(4, stok);
                stmt.setString(5, harga);
                stmt.setString(6, brand);
                stmt.setString(7, bpjsStatus);
                stmt.setString(8, nip);

                // Eksekusi query untuk menyimpan data
                int rowsInserted = stmt.executeUpdate();

                if (rowsInserted > 0) {
                    // Setelah input berhasil, reset nilai input ke default
nama_obat.setText("");  // Reset JTextField nama_obat
obat_kategori.setSelectedIndex(0); 
jenisobat.setSelectedIndex(0);// Reset JComboBox ke pilihan pertama
stok_obat.setText("");  // Reset JTextField stok_obat
harga_obat.setText("");  // Reset JTextField harga_obat
brand_obat.setText("");  // Reset JTextField brand_obat
BPJS_status.setSelectedIndex(0);  // Reset JComboBox ke pilihan pertama
// nip tidak perlu direset karena sudah di-set dengan nilai default yang tetap
                    JOptionPane.showMessageDialog(this, "Data berhasil disimpan!");
                } else {
                    JOptionPane.showMessageDialog(this, "Data gagal disimpan.");
                }
            }catch (SQLException e) {
    System.out.println("Error menyimpan data: " + e.getMessage());
    e.printStackTrace();  // Tambahkan ini untuk menampilkan error secara lengkap
    JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan data.");
}
 finally {
                // Pastikan koneksi ditutup setelah selesai
                KoneksiDatabase.tutupKoneksi(conn);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Koneksi ke database gagal.");
        }
    loadData();
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backgroundobat1 = new Apps.backgroundmenu();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        obat_kategori = new javax.swing.JComboBox<>();
        nama_obat = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        stok_obat = new javax.swing.JTextField();
        harga_obat = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        brand_obat = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        BPJS_status = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jenisobat = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_obat = new javax.swing.JTable();
        CloseButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 48)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Inventory Obat Puskesmas Kemuning");
        jLabel1.setToolTipText("");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("Input Data Obat")));
        jPanel1.setOpaque(false);
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setText("Nama Obat");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jLabel3.setText("Kategori");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 64, -1));

        obat_kategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Obat Ringan", "Obat Keras", "Obat Sangat Keras" }));
        jPanel1.add(obat_kategori, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 279, -1));
        jPanel1.add(nama_obat, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, 279, -1));

        jLabel4.setText("Stok");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 44, -1));

        stok_obat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stok_obatActionPerformed(evt);
            }
        });
        jPanel1.add(stok_obat, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 279, -1));
        jPanel1.add(harga_obat, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 279, -1));

        jLabel5.setText("Harga");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 44, -1));

        brand_obat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brand_obatActionPerformed(evt);
            }
        });
        jPanel1.add(brand_obat, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 30, 200, -1));

        jLabel6.setText("Brand");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 40, 101, -1));

        jLabel7.setText("BPJS Status");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 80, 101, -1));

        BPJS_status.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tercover", "Tidak Dicover" }));
        jPanel1.add(BPJS_status, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 70, 200, -1));

        jButton1.setText("Input Obat");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 220, 200, 42));

        jButton2.setText("Print Data Obat");
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 220, 159, 42));

        jLabel8.setText("Jenis Obat");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        jenisobat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "~Pilih Jenis Obat~", "Kapsul", "Tablet", "Sirup ", "Salep", "Injeksi", " " }));
        jPanel1.add(jenisobat, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, 279, -1));

        tabel_obat.setBackground(new java.awt.Color(204, 204, 204));
        tabel_obat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Obat", "Nama Obat", "Kategori", "Stok", "Harga", "Tercover BPJS", "Petugas Input", "Input Date", "Edit Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabel_obat.setOpaque(false);
        tabel_obat.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tabel_obat);
        if (tabel_obat.getColumnModel().getColumnCount() > 0) {
            tabel_obat.getColumnModel().getColumn(0).setResizable(false);
            tabel_obat.getColumnModel().getColumn(1).setResizable(false);
            tabel_obat.getColumnModel().getColumn(2).setResizable(false);
            tabel_obat.getColumnModel().getColumn(4).setResizable(false);
            tabel_obat.getColumnModel().getColumn(5).setResizable(false);
            tabel_obat.getColumnModel().getColumn(6).setResizable(false);
            tabel_obat.getColumnModel().getColumn(7).setResizable(false);
            tabel_obat.getColumnModel().getColumn(8).setResizable(false);
        }

        CloseButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/CloseButton.png"))); // NOI18N
        CloseButton.setBorder(null);
        CloseButton.setBorderPainted(false);
        CloseButton.setContentAreaFilled(false);
        CloseButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        CloseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CloseButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout backgroundobat1Layout = new javax.swing.GroupLayout(backgroundobat1);
        backgroundobat1.setLayout(backgroundobat1Layout);
        backgroundobat1Layout.setHorizontalGroup(
            backgroundobat1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundobat1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(backgroundobat1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, backgroundobat1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(CloseButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, backgroundobat1Layout.createSequentialGroup()
                .addContainerGap(545, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(540, 540, 540))
        );
        backgroundobat1Layout.setVerticalGroup(
            backgroundobat1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundobat1Layout.createSequentialGroup()
                .addComponent(CloseButton)
                .addGap(13, 13, 13)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(508, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(backgroundobat1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(backgroundobat1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CloseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CloseButtonActionPerformed
        new Dashboard();
        this.dispose();       // TODO add your handling code here:
    }//GEN-LAST:event_CloseButtonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        InputDataObat();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void brand_obatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brand_obatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_brand_obatActionPerformed

    private void stok_obatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stok_obatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stok_obatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Obat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Obat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Obat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Obat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        // Muat data ke dalam tabel
       
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Obat().setVisible(true);
            }
        });
    }
   private void setFullScreen() {
// Menggunakan ukuran layar penuh tanpa mode fullscreen
Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
setSize(screenSize.width, screenSize.height);
setExtendedState(JFrame.MAXIMIZED_BOTH); // Alternatif fullscreen tanpa mengubah mode penuh

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> BPJS_status;
    private javax.swing.JButton CloseButton;
    private Apps.backgroundmenu backgroundobat1;
    private javax.swing.JTextField brand_obat;
    private javax.swing.JTextField harga_obat;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> jenisobat;
    private javax.swing.JTextField nama_obat;
    private javax.swing.JComboBox<String> obat_kategori;
    private javax.swing.JTextField stok_obat;
    private javax.swing.JTable tabel_obat;
    // End of variables declaration//GEN-END:variables
}
