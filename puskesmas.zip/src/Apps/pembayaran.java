/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Apps;

import Config.KoneksiDatabase;
import com.toedter.calendar.JDateChooser;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class pembayaran extends javax.swing.JFrame {
    private Connection conn = KoneksiDatabase.getConnection();
    private DefaultTableModel tabmode;
    private java.util.Date date;
    
    
 protected void aktif (){
        jtanggal.setEnabled(true);
        idpembayaran.setEnabled(true);
        idresep.setEnabled(true);
        idtotal.setEnabled(true);
        cmetode.setEnabled(true);
    }
    
protected void kosong () {
    idpembayaran.setText("");
    idresep.setText("");
    idtotal.setText("");
    cmetode.setSelectedIndex(0); // kembali ke pilihan pertama
    jtanggal.setDate(null); // reset tanggal
}
    
        protected void datatable() throws SQLException{
        Object[] Baris ={"ID Pembayaran","ID Resep","Total Biaya","Metode Pembayaran","Tanggal Bayar"};
        tabmode = new DefaultTableModel(null,  Baris);
        tabelpembayaran.setModel (tabmode);
        String sql = "select * from pembayaran";
        try{
            java.sql.Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while(hasil.next()){
                String a = hasil.getString("id_pembayaran");
                String b = hasil.getString("id_resep");
                String c = hasil.getString("total_biaya");
                String d = hasil.getString("metode_pembayaran");
                String e = hasil.getString("tanggal_bayar");
                
                String[] data={a,b,c,d,e};
                tabmode.addRow(data);
            }
        } catch (Exception e){
          JOptionPane.showMessageDialog(null, "Gagal load data: " + e.getMessage());
          e.printStackTrace();
        }
    }
    public pembayaran() throws SQLException {
        initComponents();
       datatable();
       setFullScreen();
       
    }



    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        backgroundmenu1 = new Apps.backgroundmenu();
        btnsimpan = new javax.swing.JButton();
        btnbatal = new javax.swing.JButton();
        btncetak = new javax.swing.JButton();
        jtanggal = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        cmetode = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        idtotal = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        idresep = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        bcari = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        idpembayaran = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        ttable = new javax.swing.JScrollPane();
        tabelpembayaran = new javax.swing.JTable();
        closeButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnsimpan.setText("SIMPAN");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });

        btnbatal.setText("BATAL");
        btnbatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbatalActionPerformed(evt);
            }
        });

        btncetak.setText("CETAK KWITANSI");
        btncetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncetakActionPerformed(evt);
            }
        });

        jLabel6.setText("Tanggal Pembayaran");

        cmetode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tunai", "Transfer", "QRIS" }));

        jLabel5.setText("Metode Pembayaran");

        jLabel4.setText("Total Bayar");

        jLabel3.setText("ID Resep");

        bcari.setText("Cari");
        bcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcariActionPerformed(evt);
            }
        });

        jLabel2.setText("ID Pembayaran");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("PEMBAYARAN");

        ttable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ttableMouseClicked(evt);
            }
        });

        tabelpembayaran.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelpembayaran.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelpembayaranMouseClicked(evt);
            }
        });
        ttable.setViewportView(tabelpembayaran);

        closeButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/CloseButton.png"))); // NOI18N
        closeButton.setBorder(null);
        closeButton.setBorderPainted(false);
        closeButton.setContentAreaFilled(false);
        closeButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        closeButton.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                closeButtonMouseMoved(evt);
            }
        });
        closeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                closeButtonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                closeButtonMouseEntered(evt);
            }
        });
        closeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout backgroundmenu1Layout = new javax.swing.GroupLayout(backgroundmenu1);
        backgroundmenu1.setLayout(backgroundmenu1Layout);
        backgroundmenu1Layout.setHorizontalGroup(
            backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundmenu1Layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4)
                        .addComponent(jLabel5)
                        .addComponent(jLabel3)
                        .addComponent(jLabel2)))
                .addGap(42, 42, 42)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(backgroundmenu1Layout.createSequentialGroup()
                        .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(backgroundmenu1Layout.createSequentialGroup()
                                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(idresep, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                                    .addComponent(cmetode, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(idtotal, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(bcari, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(idpembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(backgroundmenu1Layout.createSequentialGroup()
                        .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jtanggal, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(backgroundmenu1Layout.createSequentialGroup()
                                .addComponent(btnsimpan)
                                .addGap(42, 42, 42)
                                .addComponent(btnbatal)))
                        .addGap(37, 37, 37)
                        .addComponent(btncetak)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(backgroundmenu1Layout.createSequentialGroup()
                .addGap(282, 282, 282)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(closeButton)
                .addGap(366, 366, 366))
            .addGroup(backgroundmenu1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ttable, javax.swing.GroupLayout.PREFERRED_SIZE, 1820, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(436, Short.MAX_VALUE))
        );
        backgroundmenu1Layout.setVerticalGroup(
            backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(backgroundmenu1Layout.createSequentialGroup()
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(backgroundmenu1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1))
                    .addComponent(closeButton))
                .addGap(74, 74, 74)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(idpembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(idresep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bcari))
                .addGap(18, 18, 18)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(idtotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cmetode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(26, 26, 26)
                .addGroup(backgroundmenu1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btncetak)
                    .addComponent(btnbatal)
                    .addComponent(btnsimpan))
                .addGap(37, 37, 37)
                .addComponent(ttable, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(509, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(backgroundmenu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(backgroundmenu1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        // TODO add your handling code here:
String sql = "INSERT INTO pembayaran "
                   + "(id_pembayaran, id_resep, total_biaya, metode_pembayaran, tanggal_bayar) "
                   + "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stat = conn.prepareStatement(sql)) {
            stat.setString(1, idpembayaran.getText());
            stat.setString(2, idresep.getText());
            stat.setString(3, idtotal.getText());
            stat.setString(4, cmetode.getSelectedItem().toString());
            java.sql.Date tgl = new java.sql.Date(jtanggal.getDate().getTime());
            stat.setDate(5, tgl);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data berhasil disimpan");
            kosong();
            datatable(); 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal simpan: " + e.getMessage());
        }
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void btnbatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbatalActionPerformed
        // TODO add your handling code here:
        kosong();
    }//GEN-LAST:event_btnbatalActionPerformed

    private void bcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcariActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_bcariActionPerformed

    private void btncetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncetakActionPerformed
        // TODO add your handling code here:
StringBuilder isi = new StringBuilder();
        isi.append("ID Bayar    : ").append(idpembayaran.getText()).append("\n");
        isi.append("ID Resep   : ").append(idresep.getText()).append("\n");
        isi.append("Total Bayar : ").append(idtotal.getText()).append("\n");
        isi.append("Metode      : ").append(cmetode.getSelectedItem()).append("\n");
        isi.append("Tanggal     : ").append(
            new java.text.SimpleDateFormat("yyyy-MM-dd").format(jtanggal.getDate())
        );
        JTextArea area = new JTextArea(isi.toString());
        JOptionPane.showMessageDialog(this, new JScrollPane(area), 
                                      "Kwitansi", JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_btncetakActionPerformed

    private void tabelpembayaranMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelpembayaranMouseClicked
        // TODO add your handling code here:                                     
int baris = tabelpembayaran.getSelectedRow();

    if (baris >= 0) {
        idpembayaran.setText(tabelpembayaran.getValueAt(baris, 0).toString());
        idresep.setText(tabelpembayaran.getValueAt(baris, 1).toString());
        idtotal.setText(tabelpembayaran.getValueAt(baris, 2).toString());
        cmetode.setSelectedItem(tabelpembayaran.getValueAt(baris, 3).toString());

        try {
            String tanggalString = tabelpembayaran.getValueAt(baris, 4).toString();
            java.util.Date tanggal = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(tanggalString);
            jtanggal.setDate(tanggal);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    }//GEN-LAST:event_tabelpembayaranMouseClicked

    private void ttableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ttableMouseClicked
        // TODO add your handling code here:


    }//GEN-LAST:event_ttableMouseClicked

    private void closeButtonMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeButtonMouseMoved
        // TODO add your handling code here:
    }//GEN-LAST:event_closeButtonMouseMoved

    private void closeButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeButtonMouseClicked

    }//GEN-LAST:event_closeButtonMouseClicked

    private void closeButtonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_closeButtonMouseEntered

    }//GEN-LAST:event_closeButtonMouseEntered

    private void closeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeButtonActionPerformed
        new Dashboard().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_closeButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (intxtidpembayaran Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new pembayaran().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(pembayaran.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    
           private void setFullScreen() {
// Menggunakan ukuran layar penuh tanpa mode fullscreen
Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
setSize(screenSize.width, screenSize.height);
setExtendedState(JFrame.MAXIMIZED_BOTH); // Alternatif fullscreen tanpa mengubah mode penuh

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Apps.backgroundmenu backgroundmenu1;
    private javax.swing.JButton bcari;
    private javax.swing.JButton btnbatal;
    private javax.swing.JButton btncetak;
    private javax.swing.JButton btnsimpan;
    private javax.swing.JButton closeButton;
    private javax.swing.JComboBox<String> cmetode;
    private javax.swing.JTextField idpembayaran;
    private javax.swing.JTextField idresep;
    private javax.swing.JTextField idtotal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private com.toedter.calendar.JDateChooser jtanggal;
    private javax.swing.JTable tabelpembayaran;
    private javax.swing.JScrollPane ttable;
    // End of variables declaration//GEN-END:variables
}
